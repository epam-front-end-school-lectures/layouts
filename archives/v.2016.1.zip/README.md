# Layouts, The
Slides for the lecture about different ways for creating page layout with their pros and cons

### Lates version of the presentation online

http://epam-front-end-school-lectures.github.io/layouts/index.html#/

### Download presentation
- 2016 year version (first set) - https://github.com/epam-front-end-school-lectures/layouts/archive/v.2016.1.zip
